create table add_to_cart(
mobile_number bigint,
product_name varchar(20),
product_quantity int,
total_amount bigint);