create table user(
mobile_number varchar(13) NOT NULL,
name varchar(50),
email_id varchar(50),
city varchar(50), 
primary key(mobile_number)
);