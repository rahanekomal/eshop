package com.ecommerce.onlineshopping;

public interface AdminInterface 
{
		public void checkAdmin();
		public void getQuantityStatus();
	    public void getHistoryOfPurchaseProduct();	
	    public void getRegisterUserList();
}
