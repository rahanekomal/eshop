package com.ecommerce.onlineshopping;

public interface ProductInterface 
{
	    //public void buyProducts();
		public void displayProductList();
}
