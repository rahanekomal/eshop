package com.ecommerce.onlineshopping;

public interface UserInterface 
{
	public void newRegistration(); 
	public void checkRegistration(); 
}
